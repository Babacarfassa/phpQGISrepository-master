import processing,xlwt,qgis,datetime,zipfile
from PyQt4.QtCore import *
from qgis.core import * 
from qgis.utils import *
from PyQt4.QtGui import *
from qgis.gui import *
from PyQt4 import *

from mmqgis_library import mmqgis_kml_export


def Preparation_donnees_SBO_function(layer_contour,path_csv_save,output_folder,fichier_KML_Style):

	def get_fiel_name0(layer_vector):
		field_names = [field.name() for field in layer_vector.fields()]
		field_names_first_attribut=field_names[0]
		return field_names_first_attribut

	w = QWidget()
	succesMsg="Execution-Plugin-Fini!!!!!!!!!"
	end_name_reproject='-reproject'
	def decoup_lines_points_zone():
		
		"""root = QgsProject.instance().layerTreeRoot()
		name_groupe="Shape_Decoupe"
		group = root.findGroup(name_groupe)
		if group is not None:
			for child in group.children():
				QgsMapLayerRegistry.instance().removeMapLayer(child.layerId())
		root.removeChildNode(group)
		shapeGroup = root.addGroup(name_groupe)"""
		
		dest_crs = QgsCoordinateReferenceSystem(4326)
		for layers_name_mapLayers in QgsMapLayerRegistry.instance().mapLayers().values():
			if layers_name_mapLayers.name().split('_')[-1]==end_name_reproject:
				if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer and layers_name_mapLayers.geometryType() == QGis.Line and layer_contour_reproject.geometryType()==QGis.Polygon:#Export des linestring qui interesectent la zone de decoupe
					for area_feature in layer_contour_reproject.getFeatures():
						geom_Contour=area_feature.geometry()
						bboxshape_Contour = geom_Contour.boundingBox()
						request = QgsFeatureRequest()
						request.setFilterRect(bboxshape_Contour)
						iter_layers_lines = layers_name_mapLayers.getFeatures(request)
						areas_line_intersect = []
						for line_feature in iter_layers_lines:
							if line_feature.geometry().intersects((area_feature.geometry())):
								areas_line_intersect.append(line_feature.id())
						layers_name_mapLayers.removeSelection()
						export_select=layers_name_mapLayers.select(areas_line_intersect)
						layer_export_clip_res = output_folder+layers_name_mapLayers.name().replace('_'+end_name_reproject,'')
						QgsVectorFileWriter.writeAsVectorFormat(layers_name_mapLayers,layer_export_clip_res, "LATIN1", dest_crs, "ESRI Shapefile",True)#Exporter que les elements seletionner

				if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer and layers_name_mapLayers.geometryType() == QGis.Point and layer_contour_reproject.geometryType()==QGis.Polygon:#Export des Points qui interesectent la zone de decoupe
					for area_feature in layer_contour_reproject.getFeatures():
						geom_Contour=area_feature.geometry()
						bboxshape_Contour = geom_Contour.boundingBox()
						request = QgsFeatureRequest()
						request.setFilterRect(bboxshape_Contour)
						iter_layers_points = layers_name_mapLayers.getFeatures(request)
						areas_point_intersect = []
						for point_feature in iter_layers_points:
							if point_feature.geometry().within((area_feature.geometry())):
								areas_point_intersect.append(point_feature.id())
						layers_name_mapLayers.removeSelection()
						export_select=layers_name_mapLayers.select(areas_point_intersect)
						layer_export_clip_res = output_folder+layers_name_mapLayers.name().replace('_'+end_name_reproject,'')
						QgsVectorFileWriter.writeAsVectorFormat(layers_name_mapLayers,layer_export_clip_res, "LATIN1", dest_crs, "ESRI Shapefile",True)                    
				layers_name_mapLayers.removeSelection()

					

	def trasnform_SHP_KML():
	
		root = QgsProject.instance().layerTreeRoot()
		name_groupe="Shape_Export_KML"
		group = root.findGroup(name_groupe)
		if group is not None:
			for child in group.children():
				QgsMapLayerRegistry.instance().removeMapLayer(child.layerId())
		root.removeChildNode(group)
		shapeGroup = root.addGroup(name_groupe)
		
		dest_crs = QgsCoordinateReferenceSystem(4326)#WGS84=4326; 
		selectedLayers = iface.legendInterface().selectedLayers()
		
		map_selected_recup=[]
		for layers_name_mapLayers in QgsMapLayerRegistry.instance().mapLayers().values():
			if layers_name_mapLayers.name().split('_')[-1]==end_name_reproject:
				for layer_selected_FOR_KML in selectedLayers:
					if layers_name_mapLayers.name().replace('_'+end_name_reproject,'')==layer_selected_FOR_KML.name():
						a= layers_name_mapLayers.name()
						map_selected_recup.append(layers_name_mapLayers)
						
						for  get_layer_select in map_selected_recup:
							if get_layer_select.type() == QgsMapLayer.VectorLayer and get_layer_select.geometryType() in [QGis.Line,QGis.Polygon] and layer_contour_reproject.geometryType()==QGis.Polygon:
								a= get_layer_select.type() ,';',get_layer_select.name()
		
		for layers_name_mapLayers in QgsMapLayerRegistry.instance().mapLayers().values():
			
			if layers_name_mapLayers.geometryType()==QGis.Line:                  
				lines_reproject = QgsVectorLayer("LineString?crs=epsg:4326", layers_name_mapLayers.name()+'_selected', "memory")
			elif layers_name_mapLayers.geometryType()==QGis.Point:
				lines_reproject = QgsVectorLayer("Point?crs=epsg:4326", layers_name_mapLayers.name()+'_selected', "memory")
			else:
				lines_reproject = QgsVectorLayer("Polygon?crs=epsg:4326", layers_name_mapLayers.name()+'_selected', "memory")
			  
			lines_reproject_pr2 = lines_reproject.dataProvider()
			lines_reproject_attr2 = layers_name_mapLayers.dataProvider().fields().toList()
			lines_reproject_pr2.addAttributes(lines_reproject_attr2)
			lines_reproject.updateFields()
			
			if layers_name_mapLayers.name().split('_')[-1]==end_name_reproject:
				for layer_selected_FOR_KML in selectedLayers:
					if layers_name_mapLayers.name().replace('_'+end_name_reproject,'')==layer_selected_FOR_KML.name():
						a= layers_name_mapLayers.name()
						
						for area_feature in layer_contour_reproject.getFeatures():
							geom_Contour=area_feature.geometry()
							bboxshape_Contour = geom_Contour.boundingBox()
							request = QgsFeatureRequest()
							request.setFilterRect(bboxshape_Contour)
							areas_features_intersect = []
							areas_features_Lines_intersect = []
							if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer and layers_name_mapLayers.geometryType() in [QGis.Line,QGis.Polygon] and layer_contour_reproject.geometryType()==QGis.Polygon:
								for select_layer in layers_name_mapLayers.getFeatures(request):
									if select_layer.geometry().intersects(area_feature.geometry()):
										areas_features_intersect.append(select_layer.id())
								layers_name_mapLayers.removeSelection()
								export_select=layers_name_mapLayers.select(areas_features_intersect)
								selectedFeatures = layers_name_mapLayers.selectedFeatures()
								layer_export_clip_res = output_folder+layers_name_mapLayers.name().replace('_'+end_name_reproject,'')
								#QgsVectorFileWriter.writeAsVectorFormat(layers_name_mapLayers, layer_export_clip_res, "LATIN1", dest_crs, "KML",True)
								
								lines_reproject_pr2.addFeatures(selectedFeatures)
								QgsMapLayerRegistry.instance().addMapLayer(lines_reproject,False)
								shapeGroup.insertChildNode(1,QgsLayerTreeLayer(lines_reproject))
								#layer = layer_selected_FOR_KML#qgis.utils.iface.activeLayer()
								kmlfile = fichier_KML_Style#r"C:\Users\bfassa\Downloads\KML_POLYLIGNE.qml"#fichier_KML_Style#
								if kmlfile:
									lines_reproject.loadNamedStyle(kmlfile)
								name_layer_export_kml=layers_name_mapLayers.name().replace('_'+end_name_reproject,'')+'.kml'
								mmqgis_kml_export(lines_reproject.name(),get_fiel_name0(layers_name_mapLayers), True,output_folder+name_layer_export_kml,True)#.replace(' ','')
							if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer and layers_name_mapLayers.geometryType() == QGis.Point and layer_contour_reproject.geometryType()==QGis.Polygon:
								for select_layer in layers_name_mapLayers.getFeatures(request):
									if select_layer.geometry().within((area_feature.geometry())):
										areas_features_Lines_intersect.append(select_layer.id())
								layers_name_mapLayers.removeSelection()
								export_select=layers_name_mapLayers.select(areas_features_Lines_intersect)
								layer_export_clip_res = output_folder+layers_name_mapLayers.name().replace('_'+end_name_reproject,'')
								QgsVectorFileWriter.writeAsVectorFormat(layers_name_mapLayers, layer_export_clip_res, "LATIN1", dest_crs, "ESRI Shapefile",True)
				
						layers_name_mapLayers.removeSelection()
						
	
		root = QgsProject.instance().layerTreeRoot()
		name_groupe="Shape_Export_KML"
		group = root.findGroup(name_groupe)
		if group is not None:
			for child in group.children():
				QgsMapLayerRegistry.instance().removeMapLayer(child.layerId())
		root.removeChildNode(group)


	def reproject_layers():
		
		root = QgsProject.instance().layerTreeRoot()
		name_groupe="Shape_Reproject"
		group = root.findGroup(name_groupe)
		if group is not None:
			for child in group.children():
				QgsMapLayerRegistry.instance().removeMapLayer(child.layerId())
		root.removeChildNode(group)
		shapeGroup = root.addGroup(name_groupe)
		list_shp_reproject=[]
		for layers_name_mapLayers in QgsMapLayerRegistry.instance().mapLayers().values():
			if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer and layers_name_mapLayers.geometryType() in [QGis.Point,QGis.Line,QGis.Polygon]:
				if layers_name_mapLayers.geometryType()==QGis.Line:                  
					lines_reproject = QgsVectorLayer("LineString?crs=epsg:4326", layers_name_mapLayers.name()+'_-reproject', "memory")
				elif layers_name_mapLayers.geometryType()==QGis.Point:
					lines_reproject = QgsVectorLayer("Point?crs=epsg:4326", layers_name_mapLayers.name()+'_-reproject', "memory")
				else:
					lines_reproject = QgsVectorLayer("Polygon?crs=epsg:4326", layers_name_mapLayers.name()+'_-reproject', "memory")
				  
				xform = QgsCoordinateTransform(layers_name_mapLayers.crs(), QgsCoordinateReferenceSystem(4326))

				lines_reproject_pr2 = lines_reproject.dataProvider()
				lines_reproject_attr2 = layers_name_mapLayers.dataProvider().fields().toList()
				lines_reproject_pr2.addAttributes(lines_reproject_attr2)
				lines_reproject.updateFields()
				iter_layers_lines = layers_name_mapLayers.getFeatures()
				outFeat = QgsFeature()
				for line_feature in iter_layers_lines:
					geom = line_feature.geometry()
					if geom != NULL:
						geom.transform(xform)
						outFeat.setGeometry(geom)
						outFeat.setAttributes(line_feature.attributes())
						lines_reproject_pr2.addFeatures([outFeat]) 
			list_shp_reproject.append(lines_reproject)
			QgsMapLayerRegistry.instance().addMapLayer(lines_reproject,False)
			shapeGroup.insertChildNode(1,QgsLayerTreeLayer(lines_reproject))

		return list_shp_reproject


	layer_contour_reproject='-1'
	layer_lines_reproject='-1'
	layer_points_reproject='-1'
	for shp_reproject in reproject_layers():
		if shp_reproject.geometryType() == QGis.Polygon:
			layer_contour_reproject=shp_reproject#.getFeatures()
		if shp_reproject.geometryType() == QGis.Point:
			layer_points_reproject=shp_reproject#.getFeatures()
		if shp_reproject.geometryType() == QGis.Line:
			layer_lines_reproject=shp_reproject#.getFeatures()


	trasnform_SHP_KML()

	#Zipper le dossier des resultat
	def zip_folder_res():
			
		test_path = os.path.join(path_csv_save)
		date_time = datetime.datetime.now().strftime('_%d_%m_%Y_%H_%M_%S')
		zf = zipfile.ZipFile(output_folder+'Export_Archive_SBO'+str(date_time) + '.sbo',"w")
		for dirname, subdirs, files in os.walk(test_path):
			for filename in files:
				if not filename.endswith(".sbo"):
					zf.write(os.path.join(dirname, filename), os.path.relpath(os.path.join(dirname, filename), output_folder), compress_type = zipfile.ZIP_DEFLATED)
		zf.close()

		#Suppression du group ajoute dans QGis
		root = QgsProject.instance().layerTreeRoot()
		name_groupe="Shape_Reproject"
		group = root.findGroup(name_groupe)
		if group is not None:
			for child in group.children():
				QgsMapLayerRegistry.instance().removeMapLayer(child.layerId())
		root.removeChildNode(group)
		

		rep_in=glob.glob(output_folder+'*')#.replace(' ','')+'*')
		for file_rep_in in rep_in:
			#Suppression de tous les fichiers dans ce repertoir sauf le .sbo
			if not file_rep_in.endswith(".sbo"):#or file_rep_in.endswith(".shp") or file_rep_in.endswith(".shx") or file_rep_in.endswith(".dbf") or file_rep_in.endswith(".prj") or file_rep_in.endswith(".prj"):
				os.remove(file_rep_in)

	zip_folder_res()

	QMessageBox.information(w, "Message-Execution-Plugin", succesMsg)