import processing,xlwt,qgis,datetime,zipfile,os
from PyQt4.QtCore import *
from qgis.core import * 
from qgis.utils import *
from PyQt4.QtGui import *
from qgis.gui import *
from PyQt4 import *


#fichier_KML_Style=QFileDialog.getOpenFileName(None, "Veillez choisir le fichier_KML_Style", "", "KML (*.qml)")


def ajout_style_kml_Lines_function(fichier_KML_Style):

    kmlfile = fichier_KML_Style#r"C:\Users\bfassa\Downloads\KML_POLYLIGNE.qml"
    #Lutilisateur va selectionner les couches
    selectedLayers = iface.legendInterface().selectedLayers()
    for layer_selected_FOR_KML in selectedLayers:
        if layer_selected_FOR_KML.type() == QgsMapLayer.VectorLayer and layer_selected_FOR_KML.geometryType() == QGis.Line:
            layer = layer_selected_FOR_KML#qgis.utils.iface.activeLayer()
            layer.loadNamedStyle(kmlfile)
            
#ajout_style_kml_Lines(fichier_KML_Style)